---
title: "About me"
date: 2018-03-18T21:46:43+08:00
draft: false
categories: "AboutMe"
tags: []
---


## Introduce

I am a graduate student and graduated from Southwest University of Science and Technology(西南科技大学) in in Mianyang City, Sichuan Province.
My major is computer application and network security.


## blog

* [<font color=blue>CSDN Blog</font>](http://blog.csdn.net/zg_hover)
* [<font color=blue>ChinaUnix Blog</font>](http://blog.chinaunix.net/uid/20498361.html)
