---
title: "{{ replace .TranslationBaseName "-" " " | title }}"
date: {{ .Date }}
subtitle: ""
tags: []
---
